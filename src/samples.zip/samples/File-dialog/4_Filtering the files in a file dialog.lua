
--[[
README:
  Example 4 for category File-dialog
Filtering the files in a file dialog
]]

require "gui"
local window = gui.create_window()
window.title = "Filter Demo"
    
local file_dialog = window:create_file_dialog()
file_dialog.filters = {
  { "Text files", "*.txt" },
  { "Image files", "*.jpg", "*.png", "*.gif" },
  { "All files", "*.*" }
}
    
file_dialog:open()
    
gui.run()
