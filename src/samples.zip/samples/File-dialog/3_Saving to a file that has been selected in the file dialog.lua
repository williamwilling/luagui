
--[[
README:
  Example 3 for category File-dialog
Saving to a file that has been selected in the file dialog
]]

require "gui"
local window = gui.create_window()
window.title = "Save File Demo"
local file_dialog = window:create_file_dialog()
if file_dialog:save() then
  local file = io.open(file_dialog.file_name, "w")
  file:write("Remember: save early, save often!")
  file:close()
end
gui.run()
