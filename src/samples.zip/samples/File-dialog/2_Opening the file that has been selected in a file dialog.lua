
--[[
README:
  Example 2 for category File-dialog
Opening the file that has been selected in a file dialog
]]

require "gui"
local window = gui.create_window()
window.title = "Open File Demo"
    
local text_box = window:add_text_box()
text_box.multiline = true
text_box.width = window.width
text_box.height = window.height
    
local file_dialog = window:create_file_dialog()
if file_dialog:open() then
  local file = io.open(file_dialog.file_name)
  text_box.text = file:read("*a")
  file:close()
end
    
gui.run()
