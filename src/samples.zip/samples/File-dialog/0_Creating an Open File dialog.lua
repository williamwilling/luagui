
--[[
README:
  Example 0 for category File-dialog
Creating an Open File dialog
]]

require "gui"
local window = gui.create_window()
window.title = "Open File Dialog Demo"
    
local file_dialog = window:create_file_dialog()
file_dialog:open()
    
gui.run()
