
--[[
README:
  Example 1 for category File-dialog
Creating a Save File dialog
]]

require "gui"
local window = gui.create_window()
window.title = "Save File Dialog Demo"
    
local file_dialog = window:create_file_dialog()
file_dialog:save()
    
gui.run()
