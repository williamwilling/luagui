
--[[
README:
  Example 0 for category Keyboard
Monitoring the keyboard state
]]

require "gui"
local window = gui.create_window()
window.title = "Keyboard Demo"
local timer = gui.create_timer()
timer.interval = 0.1
timer:start()
function timer:on_tick()
  if gui.keyboard.key_down.alt and gui.keyboard.key_down.x then
    window:close()
  end
end
gui.run()
