
--[[
README:
  Example 5 for category Text-box
Giving a text box focus
]]

require "gui"
local window = gui.create_window()
window.title = "Focus Demo"
local text_box = window:add_text_box()
local button = window:add_button()
button.y = text_box.height
button.text = "Focus"
function button:on_click()
  text_box:focus()
end
gui.run()
