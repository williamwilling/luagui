
--[[
README:
  Example 0 for category Text-box
Creating a text box
]]

require "gui"
local window = gui.create_window()
window.title = "Text Box Demo"
    
local text_box = window:add_text_box()
text_box.x = 8
text_box.y = 8
text_box.width = 150
    
gui.run()
