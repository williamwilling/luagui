
--[[
README:
  Example 6 for category Text-box
Selecting text in a text box
]]

require "gui"
local window = gui.create_window()
window.title = "Selection Demo"
local text_box = window:add_text_box()
text_box.text = "One, two, many"
text_box.selection.from = 6
text_box.selection.to = 8
gui.run()
