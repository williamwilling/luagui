
--[[
README:
  Example 8 for category Text-box
Replacing selected text
]]

require "gui"
local window = gui.create_window()
window.title = "Replace Demo"
local text_box = window:add_text_box()
text_box.text = "One, two, many"
text_box.selection = {
  from = 4,
  to = 9,
  text = " too"
}
gui.run()
