
--[[
README:
  Example 7 for category Text-box
Selecting all text in a text box
]]

require "gui"
local window = gui.create_window()
window.title = "Select All Demo"
local text_box = window:add_text_box()
text_box.text = "One, two, many"
text_box.selection = { from = 1, to = #text_box.text }
gui.run()
