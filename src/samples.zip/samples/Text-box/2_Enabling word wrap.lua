
--[[
README:
  Example 2 for category Text-box
Enabling word wrap
]]

require "gui"
local window = gui.create_window()
window.title = "Word Wrap Demo"
    
local text_box = window:add_text_box()
text_box.multiline = true
text_box.word_wrap = true
text_box.x = 8
text_box.y = 8
text_box.width = 150
text_box.height = 200
    
gui.run()
