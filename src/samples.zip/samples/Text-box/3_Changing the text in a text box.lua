
--[[
README:
  Example 3 for category Text-box
Changing the text in a text box
]]

require "gui"
local window = gui.create_window()
window.title = "Text Changed Demo"
    
local text_box = window:add_text_box()
text_box.multiline = true
text_box.width = 250
text_box.height = 100
text_box.text = "It was many and many a year ago,\nIn a kingdom by the sea."
    
gui.run()
