
--[[
README:
  Example 9 for category Text-box
Destroying a text box
]]

require "gui"
local window = gui.create_window()
window.title = "Destroy Demo"
local text_box = window:add_button()
text_box.y = 30
text_box.text = "Goodbye, cruel world."
local button = window:add_button()
button.text = "Destroy!"
function button:on_click()
  text_box:destroy()
end
gui.run()
