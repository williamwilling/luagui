
--[[
README:
  Example 4 for category Text-box
Responding to a text change
]]

require "gui"
local window = gui.create_window()
window.title = "Text Changed Demo"
    
local label = window:add_label()
local text_box = window:add_text_box()
text_box.y = 16
    
function text_box:on_text_changed()
  label.text = text_box.text
end
    
gui.run()
