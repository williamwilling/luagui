
--[[
README:
  Example 1 for category Mouse
Changing the mouse cursor
]]

require "gui"
local window = gui.create_window()
window.cursor = "magnifier"
gui.run();
