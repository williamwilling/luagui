
--[[
README:
  Example 0 for category Mouse
Monitoring the mouse state
]]

require "gui"
local window = gui.create_window()
window.title = "Mouse Demo"
local timer = gui.create_timer()
timer.interval = 0.1
timer:start()
function timer:on_tick()
  if gui.mouse.button_down.right then
    window:close()
  elseif gui.mouse.button_down.any then
    window.x = gui.mouse.screen_x - window.width / 2
    window.y = gui.mouse.screen_y - window.height / 2
  end
end
gui.run()
