
--[[
README:
  Example 2 for category Label
Destroying a label
]]

require "gui"
local window = gui.create_window()
window.title = "Destroy Demo"
local label = window:add_label()
label.text= "I won't be here for long."
label.y = 30
local button = window:add_button()
button.text = "Destroy!"
function button:on_click()
  label:destroy()
end
gui.run()
