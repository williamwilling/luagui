
--[[
README:
  Example 0 for category Label
Creating a label
]]

require "gui"
local window = gui.create_window()
window.title = "Label Demo"
local label = window:add_label()
label.x = 10
label.y = 10
label.text = "Hello, world!"
gui.run()
