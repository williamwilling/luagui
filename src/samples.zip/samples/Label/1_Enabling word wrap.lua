
--[[
README:
  Example 1 for category Label
Enabling word wrap
]]

require 'gui'
local window = gui.create_window()
window.title = "Word Wrap Demo"
local label = window:add_label()
label.text = "This text is too long to fit on one line, but who cares!"
label.width = 100
label.word_wrap = true
gui.run()
