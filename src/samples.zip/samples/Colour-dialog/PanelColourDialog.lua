--From http://wxlua.free.fr/wxWidgets/wxColourDialog/wxColourDialog.php

require("wx") -- inutile si on utilise wxluafreeze.exe
 
-- Création d'une frame et de son panel.
  local frame = wx.wxFrame(wx.NULL, -1, "wxColourDialog")
  local panel = wx.wxPanel(frame, -1)
 
-- Création d'un deuxième panel qui changera de couleur.
  local panel2 = wx.wxPanel(panel, -1)
 
-- Centre l'objet dialog au centre de l'écran.
  frame:Centre()   
  -- wx.wxHORIZONTAL, wx.wxVERTICAL, wx.wxBOTH ou rien
 
-- Conctruction du Sizer principal.
  local mainSizer = wx.wxBoxSizer(wx.wxVERTICAL)
 
-- On met le panel2 dans le mainSizer.
  mainSizer:Add(panel2, 1 , wx.wxGROW + wx.wxALL, 10)
 
-- On créer un bouton pour appeler la wxColourDialog.
  local bouton = wx.wxButton(panel, -1, "couleur")
 
-- On met le bouton dans le mainSizer.
  mainSizer:Add(bouton, 0, wx.wxALIGN_CENTER + wx.wxBOTTOM, 10)
 
-- On affecte le Sizer principal au Panel
  panel:SetSizer(mainSizer)
   
-- Si on "clic sur le bouton "couleur", on affiche la boîte
-- de dialogue.
  bouton:Connect(wx.wxEVT_LEFT_DOWN, function()
		
	
    local colourData = wx.wxColourData()
    local colourDialog = wx.wxColourDialog(frame, colourData)
    -- Si on "clic" sur le bouton "OK" de la boîte de dialogue.
        if (colourDialog:ShowModal() == wx.wxID_OK) then
            local data = colourDialog:GetColourData()
            local nlleCouleur = data:GetColour()
            panel2:SetBackgroundColour(nlleCouleur)
            panel2:Refresh()
        end
  end)
 
-- Démarrage de l'application.
  frame:Show(true)
  wx.wxGetApp():MainLoop()