require("wx") -- inutile si on utilise wxluafreeze.exe
 
local frame = nil
 
frame = wx.wxFrame(wx.NULL, -1, "wxPanel")
frame:Center() 

local panel = wx.wxPanel(frame, -1)
 
function colorBtnPicker(panel,x,y,color)

     
	--install(panel,x,y) 
	
	-- Création d'un panel Bordure
	local panelBorder = wx.wxPanel(panel, -1,
					wx.wxPoint(x, y), wx.wxSize(34, 24))
	panelBorder:SetBackgroundColour(wx.wxColour(wx.wxBLACK))
	
	--Création d'un panel secondaire bleu.
	local panelWhite = wx.wxPanel(panelBorder, -1,
					wx.wxPoint(2, 2), wx.wxSize(30, 20))
	panelWhite:SetBackgroundColour(wx.wxColour(wx.wxWHITE))
	
-- Création d'un panel secondaire bleu.
	local panelColor = wx.wxPanel(panelWhite, -1,
					wx.wxPoint(6, 6), wx.wxSize(18, 8))
	panelColor:SetBackgroundColour(wx.wxColour(color)) -- wx.wxColour(wx.wxBLUE)

	
			--[[
			wxColourData data;
		data.SetChooseFull(true);
		for (int i = 0; i < 16; i++)
		{
		wxColour color(i*16, i*16, i*16);
		data.SetCustomColour(i, color);
		}
		wxColourDialog dialog(this, &data);
		if (dialog.ShowModal() == wxID_OK)
		{
		wxColourData retData = dialog.GetColourData();
		wxColour col = retData.GetColour();
		myWindow->SetBackgroundColour(col);
		myWindow->Refresh();
		}
		--]]
	
	local colorChooser=function()
		
		local data = wx.wxColourData()
		data:SetChooseFull(true)
		
		local prevCouleur=panelColor:GetBackgroundColour()
		--[[rouge = prevCouleur:Red()
		vert  = prevCouleur:Green()
		bleu  = prevCouleur:Blue()
		color = string.format("rgb(%3d,%3d,%3d)", rouge, vert,bleu)
		print(color)]]
		
		local i=0 -- Position in the color palette
		--[[repeat 
			color=wx.wxColour(i*16, i*16, i*16)
			data:SetCustomColour(i, color)
			i=i+1
		 until(i==6)]]
		data:SetCustomColour(i, prevCouleur)
		data:SetColour(prevCouleur)
		
		local colourDialog = wx.wxColourDialog(frame, data)
		
		-- Si on "clic" sur le bouton "OK" de la boîte de dialogue.
			if (colourDialog:ShowModal() == wx.wxID_OK) then
				local data = colourDialog:GetColourData()
				local nlleCouleur = data:GetColour()
				rouge = nlleCouleur:Red()
				vert  = nlleCouleur:Green()
				bleu  = nlleCouleur:Blue()
				color = string.format("%3d,%3d,%3d", rouge, vert,bleu)
				print(color)
				panelColor:SetBackgroundColour(nlleCouleur)
				panelColor:Refresh()
			end
			
	
	end
	
	
	panelWhite:Connect(wx.wxEVT_LEFT_DOWN,colorChooser)
	panelColor:Connect(wx.wxEVT_LEFT_DOWN,colorChooser)
	
end
 
 
 colorBtnPicker(panel,100,100,"#2FA3FE") 
 
 colorBtnPicker(panel,10,10,"#FFA3FE") 
-- On affiche la frame.
    frame:Show(true) 
 
wx.wxGetApp():MainLoop()