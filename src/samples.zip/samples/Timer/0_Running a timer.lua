
--[[
README:
  Example 0 for category Timer
Running a timer
]]

require "gui"
local window = gui.create_window()
window.title = "Timer Demo"
local timer = gui.create_timer()
timer.interval = 1
timer:start()
local label = window:add_label()
local counter = 0
function timer:on_tick()
  counter = counter + 1
  label.text = tostring(counter)
end
gui.run()
