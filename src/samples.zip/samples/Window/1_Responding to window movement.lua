
--[[
README:
  Example 1 for category Window
Responding to window movement
]]

require "gui"
local window = gui.create_window()
window.title = "Move Demo"
function window:on_move()
  window.title = window.x .. ", " .. window.y
end
gui.run()
