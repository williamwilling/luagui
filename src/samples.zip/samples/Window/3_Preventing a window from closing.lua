
--[[
README:
  Example 3 for category Window
Preventing a window from closing
]]

require 'gui'
local window = gui.create_window()
window.title = "Close Demo"
function window:on_closing()
  return false
end
gui.run()
