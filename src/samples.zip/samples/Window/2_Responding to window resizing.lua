
--[[
README:
  Example 2 for category Window
Responding to window resizing
]]

require "gui"
local window = gui.create_window()
window.title = "Resize Demo"
function window:on_resize()
  window.title = window.width .. ", " .. window.height
end
gui.run()
