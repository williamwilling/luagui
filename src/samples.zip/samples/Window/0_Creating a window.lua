
--[[
README:
  Example 0 for category Window
Creating a window
]]

require "gui"
local window = gui.create_window()
window.title = "Window Demo"
gui.run()
