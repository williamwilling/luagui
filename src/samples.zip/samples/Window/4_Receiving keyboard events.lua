
--[[
README:
  Example 4 for category Window
Receiving keyboard events
]]

require "gui"
local window = gui.create_window()
window.title = "Keyboard Event Demo"
    
local label = window:add_label()
    
function window:on_key_down(key)
  label.text = key .. " pressed"
end
    
function window:on_key_up(key)
  label.text = key .. " released"
end
gui.run()
