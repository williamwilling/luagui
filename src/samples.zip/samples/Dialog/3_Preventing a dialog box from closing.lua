
--[[
README:
  Example 3 for category Dialog
Preventing a dialog box from closing
]]

require 'gui'
local window = gui.create_window()
window.title = "Close Demo"
local dialog = window:create_dialog()
function dialog:on_closing()
  return false
end
dialog:show_modeless()
gui.run()
