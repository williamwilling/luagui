
--[[
README:
  Example 1 for category Dialog
Creating a modal dialog box
]]

require "gui"
local window = gui.create_window()
window.title = "Modal Dialog Demo"
    
local dialog = window:create_dialog()
dialog.title = "Modal Dialog"
dialog:show_modal()
    
gui.run()
