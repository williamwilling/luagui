
--[[
README:
  Example 0 for category Dialog
Creating a modeless dialog box
]]

require "gui"
local window = gui.create_window()
window.title = "Modeless Dialog Demo"
    
local dialog = window:create_dialog()
dialog.title = "Modeless Dialog"
dialog:show_modeless()
    
gui.run()
