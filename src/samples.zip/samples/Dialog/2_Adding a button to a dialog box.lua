
--[[
README:
  Example 2 for category Dialog
Adding a button to a dialog box
]]

require "gui"
local window = gui.create_window()
window.title = "Button Dialog Demo"
    
local dialog = window:create_dialog()
dialog.title = "Button Dialog"
    
local button = dialog:add_button()
button.text = "Close"
    
function button:on_click()
  dialog:close()
end
    
dialog:show_modal()
    
gui.run()
