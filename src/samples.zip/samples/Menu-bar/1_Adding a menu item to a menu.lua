
--[[
README:
  Example 1 for category Menu-bar
Adding a menu item to a menu
]]

require "gui"
local window = gui.create_window()
window.title = "Menu Item Demo"
local file_menu = window.menu_bar:add_menu("&File")
file_menu:add_item("E&xit")
gui.run()
