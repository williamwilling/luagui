
--[[
README:
  Example 3 for category Menu-bar
Responding to selecting a menu item
]]

require "gui"
local window = gui.create_window()
window.title = "Select Demo"
local file_menu = window.menu_bar:add_menu("&File")
local exit_menu_item = file_menu:add_item("E&xit")
    
function exit_menu_item:on_select()
  window:close()
end
gui.run()
