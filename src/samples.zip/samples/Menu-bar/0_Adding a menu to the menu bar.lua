
--[[
README:
  Example 0 for category Menu-bar
Adding a menu to the menu bar
]]

require "gui"
local window = gui.create_window()
window.title = "Menu Demo"
window.menu_bar:add_menu("&File")
gui.run()
