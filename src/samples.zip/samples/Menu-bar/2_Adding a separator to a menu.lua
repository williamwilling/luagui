
--[[
README:
  Example 2 for category Menu-bar
Adding a separator to a menu
]]

require "gui"
local window = gui.create_window()
window.title = "Separator Demo"
local file_menu = window.menu_bar:add_menu("&File")
file_menu:add_item("&New")
file_menu:add_separator()
file_menu:add_item("E&xit")
gui.run()
