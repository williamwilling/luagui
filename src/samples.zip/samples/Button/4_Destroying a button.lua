
--[[
README:
  Example 4 for category Button
Destroying a button
]]

require "gui"
local window = gui.create_window()
window.title = "Destroy Demo"
local button = window:add_button()
button.text = "Destroy!"
function button:on_click()
  button:destroy()
end
gui.run()
