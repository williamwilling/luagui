--[[
README:
  Example 1 for category Button
Responding to a button click
]]

require "gui"
require "wx"
--local window = gui.create_window()
--window.title = "Click Demo"
--local button = window:add_button()
local ID_CLICK1 = 1

  local frame = wx.wxFrame(wx.NULL, wx.wxID_ANY, 'Click Coloured demo', wx.wxDefaultPosition, wx.wxDefaultSize, wx.wxCAPTION + wx.wxCLOSE_BOX + wx.wxRESIZE_BORDER + wx.wxFRAME_NO_TASKBAR + wx.wxFRAME_FLOAT_ON_PARENT)
  local panel = wx.wxPanel(frame, wx.wxID_ANY)
  
      local bouton1 = wx.wxButton(panel, ID_CLICK1, "Bouton N°1",
                    wx.wxPoint(50, 50), wx.wxSize(150, 30),
                    wx.wxBU_LEFT)
				
		
		local staticTexte1 = wx.wxStaticText(panel, -1, "text",
                         wx.wxPoint(30, 10), wx.wxDefaultSize,
                         wx.wxALIGN_LEFT)
		
--Colors : https://schlemmersoft.de/en/node/69276
  -- panel:SetBackgroundColour(wx.wxColour("RED"));
staticTexte1:SetForegroundColour(wx.wxColour("RED"));   
staticTexte1:SetBackgroundColour(wx.wxColour("WHITE"))
bouton1:SetForegroundColour(wx.wxColour("RED"));
bouton1:SetBackgroundColour(wx.wxColour("YELLOW"))
panel:SetBackgroundColour(wx.wxColour("YELLOW"))
frame:SetBackgroundColour(wx.wxColour("GREEN"))

   --txt = wx.wxStaticText( install, wxID_ANY,wxT("Validation failed"), wxPoint(10, 5), wxDefaultSize, 0 );
--txt->Show(true);
 frame:Show()
wx.wxGetApp():MainLoop() 
--end
--gui.run()
