
--[[
README:
  Example 2 for category Button
Changing the alignment of text on a button
]]

require "gui"
local window = gui.create_window()
window.title = "Alignment Demo"
local button = window:add_button()
button.text = "Hello"
button.height = 100
button.alignment = "bottom left"
gui.run()
