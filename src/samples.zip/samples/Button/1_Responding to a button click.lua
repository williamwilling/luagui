
--[[
README:
  Example 1 for category Button
Responding to a button click
]]

require "gui"
local window = gui.create_window()
window.title = "Click Demo"
local button = window:add_button()
button.x = 10
button.y = 10
button.text = "OK"
function button:on_click()
  button.text = "You clicked?"
end
gui.run()
