
--[[
README:
  Example 0 for category Button
Creating a button
]]

require "gui"
local window = gui.create_window()
window.title = "Button Demo"
local button = window:add_button()
button.x = 10
button.y = 10
button.text = "OK"
gui.run()
