
--[[
README:
  Example 3 for category Button
Enabling word wrap
]]

require "gui"
local window = gui.create_window()
window.title = "Word Wrap Demo"
local button = window:add_button()
button.text = "This text is too long to fit on one line, but who cares!"
button.width = 100
button.height = 100
button.word_wrap = true
function button:on_click()
  button.word_wrap = not button.word_wrap
end
gui.run()
