
--[[
README:
  Example 1 for category Image
Responding to a mouse button
]]

require "gui"
local window = gui.create_window()
window.title = "Mouse Button Demo"
local image = window:add_image()
image.file_name = "logo.png"
function image:on_mouse_up(button)
  if button == "left" then
    image.file_name = "left.jpg"
  elseif button == "right" then
    image.file_name = "right.jpg"
  end
end
gui.run()
