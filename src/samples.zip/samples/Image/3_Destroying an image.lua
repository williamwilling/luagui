
--[[
README:
  Example 3 for category Image
Destroying an image
]]

require "gui"
local window = gui.create_window()
window.title = "Destroy Demo"
local image = window:add_image()
image.file_name = "logo.png"
image.y = 30
local button = window:add_button()
button.text = "Destroy!"
function button:on_click()
  image:destroy()
end
gui.run()
