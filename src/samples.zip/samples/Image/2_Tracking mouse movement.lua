
--[[
README:
  Example 2 for category Image
Tracking mouse movement
]]

require "gui"
local window = gui.create_window()
window.title = "Mouse Movement Demo"
    
local label = window:add_label()
    
local image = window:add_image()
image.file_name = "/home/james/Téléchargements/brane/ZeroBraneStudio/myprograms/luagui-samples/Image/logo.png"
image.x = 25
image.y = label.height
function image:on_mouse_move(x, y)
  label.text = x .. ", " .. y
end
gui.run()
