
--[[
README:
  Example 0 for category Image
Creating an image
]]

require "gui"
local window = gui.create_window()
window.title = "Image Demo"
local image = window:add_image()
image.file_name = "logo.png"
gui.run()
